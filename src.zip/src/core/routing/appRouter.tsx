import { lazy } from "react";
import { createBrowserRouter } from "react-router-dom";
import { ProtectedLayout } from "../../App";
import panelsLoader from "./loaders/panel.loader";

const HomePage = lazy(() => import("#pages/HomePage"));
const LoginPage = lazy(() => import("#pages/LoginPage"));
const PanelsPage = lazy(() => import("#pages/PanelsPage"));
const CommingPage = lazy(() => import("#pages/Comming"));
const TestPage = lazy(() => import("#pages/desing-page"));
const TheTavloDashboard = lazy(() => import("#pages/desing"));

export const appRouter = createBrowserRouter([
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    element: <ProtectedLayout />,
    children: [
      {
        path: "/home",
        children: [
          { index: true, element: <HomePage /> },
          { path: "panels", element: <PanelsPage />, loader: panelsLoader },
        ],
      },
    ],
  },

  // {
  //   path: "/",
  //   element: <CommingPage />,
  // },
  {
    path: "/dev",
    element: <TestPage />,
  },
  {
    path: "/dash",
    element: <TheTavloDashboard />,
  },
]);
