export default function ExamsList({ panelId }: { panelId: string }) {
  return <div>Vista de Exámenes para panel: {panelId}</div>;
}