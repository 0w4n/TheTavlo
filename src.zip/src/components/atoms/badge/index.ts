export { Badge } from "./badge";
export type { BadgeProps, BadgeVariant, BadgeSize } from "./badge.types";
