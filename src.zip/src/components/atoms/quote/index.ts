export { Quote } from "./quote";
export type { QuoteProps, QuoteVariant, QuoteSize } from "./quote.types";
