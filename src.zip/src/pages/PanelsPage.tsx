import Icon from "#shared/ui/atoms/icons";

export default function PanelsPage() {
  return (
    <>
      <div>
        <div>
          <Icon name="IconTool" stroke={1.5} />
          <h1>Página en construcción</h1>
          <p>Estamos trabajando en esta sección. !Vuleve pronto¡</p>
        </div>
      </div>
    </>
  );
}
