import { IconBuilding } from "@tabler/icons-react";

export default function CommingPage() {
  return (
    <>
      <div>
        <h1>Estamos en ello</h1>
        <IconBuilding />
      </div>
    </>
  );
}
