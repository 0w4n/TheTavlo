export interface PanelContext {
  panelId: string;
}
