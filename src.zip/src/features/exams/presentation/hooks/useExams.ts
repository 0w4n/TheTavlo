export default function useExams() {

}